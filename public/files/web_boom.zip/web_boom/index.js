// Function to obfuscate encoding using XOR
function encode(input, key) {
    var charCodeMap = [];
    var result = "";

    for (var i = 1; i <= 255; i++) {
        charCodeMap[String.fromCharCode(i)] = i;
    }

    for (var j = k = 0; k < input.length; k++) {
        result += String.fromCharCode(charCodeMap[input.charAt(k)] ^ charCodeMap[key.charAt(j)]);
        j = (j + 1) % key.length;
    }

    return result;
}

// Function to validate credentials and display result
function validate() {
    var user = document.getElementById(decode("dXNu")).value;  // Decoded 'username'
    var pass = document.getElementById(decode("cGFzcw==")).value; // Decoded 'password'

    if (user === decode("YWRtMW4=") && pass === decode("STExSSExaTEhSSFJISSEh")) {  // Decoded values
        document.getElementById(decode("ZXJyb3I=")).textContent = decode("Q29ycmVjdCEgRmxhZzog") + encode(decode("V3RSU3s2Tl09Q1BT"], "MQ==")); // Decoded and encoded flag message
    } else {
        document.getElementById(decode("ZXJyb3I=")).textContent = decode("WW91ciB1c2VybmFtZSBhbmQgcGFzc29yZCBhcmUgaW5jb3JyZWN0Lg==");  // Decoded error message
    }
}

// Decode base64-encoded strings
function decode(encodedStr) {
    return atob(encodedStr);
}
